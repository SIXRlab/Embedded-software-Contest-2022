#include "main.h"

#define PWM_FREQ                    1000   
#define PWM_WIDTH                   (TIMER_PRESCALER_FREQ / PWM_FREQ)

int relay_state = 0;
// relay_state = 0 -> Light Off -> Brake OFF
// relay_state = 1 -> Light On  -> Brake ON


/* GPIOA_PIN2_GPIO INPUT MODE SET*/
void Init_GPIO_IN() {
  
  GPIO_InitTypeDef GPIO_InitStructure;
  
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);  
  
  GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_2;  
  GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IN;
  GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_NOPULL;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;  
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;  
  GPIO_Init(GPIOA, &GPIO_InitStructure);        
}

/* GPIOC_PIN2_GPIO OUTPUT MODE SET*/
void Init_GPIO_OUT() {
  
  GPIO_InitTypeDef GPIO_InitStructure;
  
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
  
  GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_2;  
  GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_NOPULL;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;  
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;  
  GPIO_Init(GPIOC, &GPIO_InitStructure);      
}

/* TIME INTERRUPT SET*/
/* 100Hz Set */

void System_Time_SET(void)
{
    SystemCoreClockUpdate();
        if (SysTick_Config(SystemCoreClock / 100))   // 20Hz tick interrupt
        {            
            assert_param(0);
        }    
}

/*
void TIM2_Configuration(void)
{
  TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
  
  TIM_TimeBaseStructure.TIM_Prescaler = 1;
  TIM_TimeBaseStructure.TIM_Period = 839999;
  TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
  TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
  TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
  
  //TIM_TimeBaseInit(TIM2, &TIM_BaseStruct);
  TIM_Cmd(TIM2, ENABLE);
  
//  
//      Frequency(Hz) = Timer Clock / (TIM_Period+1) / (TIM_Prescaler+1)
//      50HZ = 84000000HZ / 840000 / 2
      
//      = Period(1/Freq)(sec) / (TIM_Period+1)
//      = 20ms / 840000
//      = 0.024us
  
}

void TIM2_PWM_Configuration(void)
{
  TIM_OCInitTypeDef TIM_OCStruct;
  
  TIM_OCStruct.TIM_OCMode = TIM_OCMode_PWM2;
  TIM_OCStruct.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCStruct.TIM_OCPolarity = TIM_OCPolarity_Low;
    
  TIM_OC3Init(TIM2, &TIM_OCStruct); // PWM Servo Motor
 
  
  //TIM2->CCR3 = 300000;
  //TIM2->CCR3 = 118000;
  TIM2->CCR3 = 30000 ;
}

void TIM2_PWM_GPIO_Configuration(void)
{
  GPIO_InitTypeDef GPIO_InitStruct;
  
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
  
  GPIO_PinAFConfig(GPIOB, GPIO_PinSource1, GPIO_AF_TIM2);
  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_Init(GPIOB, &GPIO_InitStruct);
  
}

*/

#define TIMER_PRESCALER_FREQ        1000000             // timer �Է� Ŭ�� 1MHz
#define PWM_FREQ                    1000                // PWM �ݺ� �ֱ� 1ms = 1kHz
#define PWM_WIDTH                   (TIMER_PRESCALER_FREQ / PWM_FREQ)

#define DUTY_IDLE                   (PWM_WIDTH / 2)     // 50% duty
#define DUTY_MAX                    (PWM_WIDTH - 1)     // �ִ� duty ��.

int main()
{
  BOARD();   GPIO_SET();  DAC_C1();  ADC_C1(); LED_D2_ON();  LLIO_Init(115200);
  
  Init_GPIO_IN();
  Init_GPIO_OUT();
  GPIO_WriteBit(GPIOC, GPIO_Pin_0, Bit_SET);
  System_Time_SET();
  
//  TIM2_Configuration();
//  TIM2_PWM_Configuration();
//  TIM2_PWM_GPIO_Configuration();
  
  __WFI(); // Interrupt
  
  uint16_t PrescalerValue;
  TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
  TIM_OCInitTypeDef TIM_OCInitStructure;
  GPIO_InitTypeDef GPIO_InitStructure;
  unsigned short duty;
  char buff[128];
  
  
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
  
  GPIO_PinAFConfig(GPIOB, GPIO_PinSource1, GPIO_AF_TIM3);
  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  
  SystemCoreClockUpdate();
  PrescalerValue = (uint16_t) (SystemCoreClock / 2 / TIMER_PRESCALER_FREQ) - 1;   // timer base counter�� 1MHz �Է�
 
  TIM_TimeBaseStructure.TIM_Period = TIMER_PRESCALER_FREQ / PWM_FREQ - 1;     // 1kHz timer
  TIM_TimeBaseStructure.TIM_Prescaler = PrescalerValue;
  TIM_TimeBaseStructure.TIM_ClockDivision = 0;
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  
  TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
  
  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_Pulse = DUTY_IDLE;       // default 50%
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
  TIM_OC4Init(TIM3, &TIM_OCInitStructure);
  TIM_OC4PreloadConfig(TIM3, TIM_OCPreload_Disable);
 
  TIM_Cmd(TIM3, ENABLE);  
  
  while(1)
  { 
    TIM_SetCompare4(TIM3, (uint16_t)duty);    
  }   
}



/* Interrut RUNIING */
void SysTick_Handler(void) 
{   
  if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_2) && relay_state == 0)      
    {
      LED_D2_ON();      
      relay_state = 1;
      GPIOC->BSRRL = GPIO_Pin_2;
    }
  else if(!GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_2) && relay_state == 1)
    {
      LED_D2_OFF();
      relay_state = 0;
      GPIOC->BSRRH = GPIO_Pin_2;
    }
}