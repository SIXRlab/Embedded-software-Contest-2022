import serial
import RPi.GPIO as GPIO
import time
import smtplib, subprocess, datetime
import pygame
from pygame import mixer
import threading
import time

GPIO.setmode(GPIO.BCM)

AHRS = serial.Serial('/dev/ttyUSB0', 115200)
NANO = 23

GPIO.setup(NANO, GPIO.IN)

cnt = 0
transmitted_string = ""

pygame.mixer.init()
p1 = pygame.mixer.Sound('365a-stereo.wav')
pygame.mixer.music.set_volume(0.5)

def send_mail():
	sendEmail = "jyj105@naver.com"
	recvEmail = "jyj1055@kumoh.ac.kr"
	password = ""
	
	smtpName = "smtp.naver.com"
	smtpPort = 587
	
	text = "accident occuration"
	msg = MIMEText(text)
	
	msg['Subject'] = "SOS"
	msg['From'] = "jyj1055@naver.com"
	msg['To'] = "jyj1055@kumoh.ac.kr"
	
	s = smtplib.SMTP(smtpName, smtpPort)
	s.starttls()
	s.login(sendEmail, password)
	s.sendmail(sendEmail, recvEmail, msg.as_string())
	s.close()
	
def slip_sense():
	global transmitted_string
	global cnt
	
	bSlip = 0
	bSendMail = 0
	while True:
		if AHRS.inWaiting():
			while AHRS.inWaiting():
				transmitted_string += AHRS.read().decode("UTF-8")
			sliced_string = transmitted_string[1:-2]
			splited_string = sliced_string.split(",")
			
			roll = float(splited_string[0])
			print(roll);

			New_ROLL = roll
			if(New_ROLL < 0): 
				New_ROLL *= -1
			
			if(New_ROLL>70):
				cnt+=1
				print("Warning")
				p1.play()
					
				if(cnt>100):
					pygame.mixer.stop()
					pygame.mixer.music.set_volume(1.0)
					p1.play()
					if(bSendMail == 0):
						send_mail()
						bSendMail = 1	
					print("sendmail")
					pygame.mixer.stop()
					#bSleep = 1
			else:
				cnt = 0
				#bSleep = 0
				pygame.mixer.stop()
				
		transmitted_string = ""

	return -1;

def NANO_spk():
	#print("GPIO_DATA -->", value)
	while True:
		value = GPIO.input(NANO)
		if value == 1:
			p1.start()
			print("GPIO_DATA -->", value)
			print("success")
		elif value == 0:
			#p2.start()
			#p2.terminate()
			print('fail')
		else:
			print('error')
		time.sleep(0.01);
	return -1;


t1 = threading.Thread(target = slip_sense)
t1.demon = True
t1.start()

t2 = threading.Thread(target = NANO_spk)
t2.demon = True
t2.start()

while True:
	time.sleep(1)
